function blue()
{
  document.getElementById("rightbox").style.backgroundColor = "blue";
  document.getElementById("text").innerHTML = "hi, my name is blue";

    var string = "Blue";
    var count = 0;
    
    for (i = 0; i < string.length; i++) {
        count = count + string.charCodeAt(i);
    }
    document.getElementById("calculation").innerHTML = count;

   
}

function green()
{
  document.getElementById("rightbox").style.backgroundColor = "green";
  document.getElementById("text").innerHTML = "hi, my name is green";

  var string = "Green";
  var count = 0;
  
  for (i = 0; i < string.length; i++) {
      count = count + string.charCodeAt(i);
  }
  document.getElementById("calculation").innerHTML = count;

 
}

function red()
{
  document.getElementById("rightbox").style.backgroundColor = "red";
  document.getElementById("text").innerHTML = "hi, my name is red";

  var string = "Red";
  var count = 0;
  
  for (i = 0; i < string.length; i++) {
      count = count + string.charCodeAt(i);
  }
  document.getElementById("calculation").innerHTML = count;

 
}